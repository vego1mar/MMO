function f = f13(x)
    f = -exp(cos(2.*x));
end
